import boto3
import os

def handler(event, context):
    rds = boto3.client('rds')
    db_identifier = os.environ['DB_INSTANCE_IDENTIFIER']
    
    try:
        rds.stop_db_instance(DBInstanceIdentifier=db_identifier)
        return {'statusCode': 200, 'body': f'Successfully stopped {db_identifier}'}
    except Exception as e:
        print(f'Error: {str(e)}')
        return {'statusCode': 500, 'body': f'Error: {str(e)}'}
